package com.mAadhar.testing;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class LoginServiceTest {
	
	WebDriver driver;
	@BeforeTest
	public void config() {
		
		System.out.println("Test Started...");
		WebDriverManager.chromedriver().setup();
	  	driver=new ChromeDriver();
	  	driver.manage().window().maximize();
	  	  	
  }

  @AfterTest
  public void afterClass() {
	  
	  driver.close();
	  System.out.println("Test Completed...");
	  
  }
  
  @BeforeMethod
  public void BeforeMethod() {
	 
	  System.out.println("New Method Started...");
	  
  }
  
  @AfterMethod
  public void AfterMethod() {
	 
	  System.out.println("Method Completed...");
	  
  }


  @Test
  public void LoginTest() {
	  
	  driver.get("http://localhost:4200/login");
	  System.out.println("");
	 
  }

  
  @Test
  public void LoginTest2() throws Exception {
		  
		  driver.get("http://localhost:4200/login");
		  WebElement Email = driver.findElement(By.id("email"));
		  Email.sendKeys("ashil@gmail.com");
		  System.out.println("Email ID : " +Email.getAttribute("value"));
		  Thread.sleep(6000);
		  WebElement Password = driver.findElement(By.id("pass"));
		  Password.sendKeys("Ashil@123");
		  System.out.println("Password : " +Password.getAttribute("value"));
		  Thread.sleep(6000);
		  WebElement User = driver.findElement(By.id("user"));
		  User.click();
		  System.out.println("Type Of User : " +User.getAttribute("value"));
		  Thread.sleep(6000);
		  WebElement Submit = driver.findElement(By.id("submit"));
		  
			Submit.click();
			Thread.sleep(6000);
			
			System.out.println("-----------------------------------------");
			System.out.println("Current Page URL is : " +driver.getCurrentUrl());
			System.out.println("Current Page Title is : " +driver.getTitle());
			System.out.println("-----------------------------------------");
	
  }
	
  @Test
  public void SignupTest() {
	  
	  driver.get("http://localhost:4200/signup");
	  
  }
}
